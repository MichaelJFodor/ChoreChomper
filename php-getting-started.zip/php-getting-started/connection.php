<?php
$host="98.207.235.91";
$port=3306;
$socket="";
$user="chorechomper";
$password="chorechomper";
$dbname="chorechomper";

$con = new mysqli($host, $user, $password, $dbname, $port, $socket)
	or die ('Could not connect to the database server' . mysqli_connect_error());
	$sql = "INSERT into user (Email,FirstName,LastName,Password,Phone,Username) Values ('hsl907ue', 'teadfdfapp', '12434', 'vigckis computer', 'pi34zza', 'lindfgell')";
	mysqli_query($con,$sql);
	$con->close();
?>

