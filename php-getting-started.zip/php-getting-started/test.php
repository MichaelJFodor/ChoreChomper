<?php
echo 'Current PHP version: ' . phpversion();

phpinfo();

?>